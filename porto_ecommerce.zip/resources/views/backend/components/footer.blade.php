<div class="footer">
    <p class="mb-0">copyright@2021 | Developed By : <a href="" target="_blank">Sohel</a>
    </p>
</div>
